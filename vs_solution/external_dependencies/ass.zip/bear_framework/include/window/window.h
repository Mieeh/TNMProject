#pragma once

#define DEFAULT_CLEAR_COLOR { 1.0f, 1.0f, 1.0f }

/* Include GLFW implementation class */
#include"GLFW_window.h"
#include"GLFW_event.h"